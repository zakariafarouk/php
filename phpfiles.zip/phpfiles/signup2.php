<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="signup2.css">
    <title>signup</title>
</head>
<body>
    <?php 
include_once 'connexion.php' ; 

$nom = $_POST['nom'] ;
$prenom = $_POST['prenom'] ;
$cne = $_POST['cne'] ;
$email = $_POST['email'] ;
$tel = $_POST['tel'] ;
$xpl=explode('.',$_FILES['photo']['name']);
$file_ext = strtolower(end($xpl));

$username = $_POST['username'] ;
$password = $_POST['password'] ; 
$photo=$username.".".$file_ext;
$sql = "INSERT INTO etudiant(user,nom,prenom,cne,email,tel,photo) VALUES ('$username','$nom' ,'$prenom','$cne','$email','$tel','$photo');";
$result1 = mysqli_query ($connex,$sql) ;
if($result1==1){
    $file_tmp = $_FILES['photo']['tmp_name'];
    move_uploaded_file($file_tmp,"photo/".$photo);
    $requete = "SELECT id FROM etudiant where 
    user = '".$username."' ";
    $result = mysqli_query($connex,$requete);
    $row= mysqli_fetch_assoc($result);
    $id= $row['id'];
$sql = "INSERT INTO compte(id,user,pass) VALUES ('$id','$username' ,'$password' );";
$result2 = mysqli_query ($connex,$sql) ;
echo "<center><h1>you created an account </h1>
<h1>".$result1."</h1>
<p>your user name is:  
    <br>
    <div>".$username."</div>
    
</p> 
<p><a href=\"index.php\">page d'acceuil</a></p>

</center>";
}else{
    echo "<center><h1>try another username</h1><a  class=\"res\"  href=\"signup.php\">try again</a></center>";}


?>



</body>
</html>
