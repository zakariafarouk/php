<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
</head>
<body>
    <?php
    $dbservername="localhost";
    $dbusername="root";
    $dbpassword="";
    $dbname="ginf1";

    $connex = mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);
    
    
    ?>

</body>
</html>