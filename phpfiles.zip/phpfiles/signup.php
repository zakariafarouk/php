<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="signup.css">
    <title>signup</title>
</head>
<body>
<a class="home"  style="text-decoration:none" href="index.php">home page</a> 
<center>   
<h1>Inscription</h1>
</center>
<br><form action="./signup2.php" method="POST" enctype="multipart/form-data">
<center>    
<div class="photo" ><input type="image" alt="image" src="./photo/999.png" width="150px"> <input type="file" accept="image/png, image/jpeg" name="photo" required></div>
</center>
<center>
  <p><label>first name</label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="a" required type="text" name="nom"></p>
  <p><label>last name</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="a" required type="text" name="prenom"></p>
  <p><label>cne</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="a" required type="text" name="cne"></p>
  <p><label>email</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="a" required type="email" name="email"><div></div></p>
  <p><label>phone</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="a" required type="tel" pattern="[0-9]{10}" name="tel"><div></div></p>
  <p><label>username</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="a" required type="text" name="username"><div></div></p>
  <p><label>password</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="a" required type="password" name="password"><div></div></p>
 
</center>
<center> 
<input class="a" type="submit" name="submit" value="Confirmer">
</center>
    </form>
</body>
</html>