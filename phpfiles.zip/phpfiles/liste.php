<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="liste.css">
    <title>LISTE DES ETUDIANT</title>
</head>
<body>
    
<?php include_once 'connexion.php' ; 
  if(isset($_SESSION['username']) and isset($_SESSION['password'])){
    abc:
    echo "<div><a href='deconnexion.php'>deconnexion</a></div>";
    $requete = "SELECT * FROM etudiant";
            $result = mysqli_query($connex,$requete);
            echo "<center><table border='1' ";
            echo "<tr>
            <td>nom</td>
            <td>prenom</td>
            <td>cne</td>
            <td>email</td>
            <td>tel</td>
            <td>PHOTO</td>
            </tr>";
            while($row= mysqli_fetch_assoc($result)){
                echo "<tr>
                <td>".$row['nom']."</td>
                <td>".$row['prenom']."</td>
                <td>".$row['cne']."</td>
                <td>".$row['email']."</td>
                <td>".$row['tel']."</td>
                <td><img  alt=\"image\" src=\"./photo/".$row['photo']."\" width=\"160\" height=\"160px\"></td>
                </tr>";
            }
            echo "</table></center>";
    }else{ if(isset($_POST['username']) and isset($_POST['password'])){
        $_SESSION['username']=$_POST['username'];
        $_SESSION['password']=$_POST['password'];
    


        
        $requete = "SELECT id FROM compte where 
              user = '".$_SESSION['username']."' and pass = '".$_SESSION['password']."' ";
        $result = mysqli_query($connex,$requete);
        $resultcheck = mysqli_num_rows($result);
        
        if($resultcheck==1) 
        {
            goto abc;
        }
        else
        {   $_SESSION['eror']="incorect username or password";
            $_SESSION['user']=$_SESSION['username'];

            unset($_SESSION['username']);
            unset($_SESSION['password']);
            
            header("Location: index.php");
            
        }
    
    }}
    
    ?>
    
</body>
</html>