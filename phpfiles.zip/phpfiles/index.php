<?php session_start(); 
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="index.css">
    <title>espace_etudiant</title> 
</head>
<body>
    <?php if(isset($_SESSION['username']) and isset($_SESSION['password'])){
        header("Location: liste.php");
        exit;
    }
    
     ?>

       
            <center>
            <p class="title">Home Page</p>
            </center>
            <form action="liste.php" method="POST" >
               <center>
                    <p>   
                     <label class="name" >Username  </label>
                     <input type="text" name="username" required value="<?php if(isset($_SESSION['user'])){
                     echo $_SESSION['user'];
                     unset($_SESSION['user']);} ?>"> 
                    </p>
               </center> 
               <center>
                  <p>
                    <class class="user">Password  </class>
                    <input type="password" name="password" required> 
                  </p>
               </center>  
                   <div id="page">
                    <input class="submit"  type="submit" name="submit" value="Login">
                    <a href="signup.php" style="text-decoration:none" class="login">Register</a><br>
                   </div>
                   <div><?php if(isset($_SESSION['eror'])){
                    echo $_SESSION['eror'];
                    unset($_SESSION['eror']);
                   } ?></div>
            </form>
            
  
</body>
</html>